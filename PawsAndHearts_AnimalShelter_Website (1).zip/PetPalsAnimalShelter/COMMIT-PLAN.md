# Suggested GitHub commit plan

Make small, meaningful commits as you complete each stage:
1. Create initial shelter website structure
2. Add shared responsive stylesheet and navigation
3. Add home and about pages
4. Add shelter services and FAQ accordion
5. Add pet profiles with search and filter
6. Add dynamic events and enquiry forms
7. Add contact and privacy pages
8. Update documentation and test website

Do not create commits claiming features that have not been added or tested.
