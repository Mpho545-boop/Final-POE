# Website test checklist

- [ ] Home page loads and navigation works.
- [ ] About, services, pets, events, enquiry, contact and privacy pages open.
- [ ] CSS and JavaScript load on every page.
- [ ] Mobile navigation opens and closes.
- [ ] Pet search filters by name/breed.
- [ ] Dog/cat filter works.
- [ ] Event cards appear.
- [ ] FAQ accordion expands and collapses.
- [ ] Enquiry form blocks missing/invalid required fields.
- [ ] Contact form validates required fields.
- [ ] Lightbox opens and closes on pages with gallery images.
- [ ] Images load with an internet connection.
