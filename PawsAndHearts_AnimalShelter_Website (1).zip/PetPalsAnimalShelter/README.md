# Paws & Hearts Animal Shelter Website

A responsive multi-page website project for a fictional community animal shelter that cares for dogs and cats.

## Open the website
1. Download and extract the project folder.
2. Open the `PetPalsAnimalShelter` folder in Visual Studio Code.
3. Install the **Live Server** extension.
4. Open `index.html` and select **Go Live**.

You can also open `index.html` directly in a browser, although Live Server is recommended.

## Pages
- `index.html` – Home
- `about.html` – About the shelter
- `services.html` – Rescue, care, adoption and volunteering services
- `pets.html` – Sample pet profiles with search and type filter
- `events.html` – Dynamically generated sample events
- `enquiry.html` – Adoption/foster/volunteer enquiry form
- `contact.html` – Contact details and message form
- `privacy.html` – Privacy notice

## Features
- Shared responsive stylesheet in `css/style.css`
- Shared JavaScript in `js/main.js`
- Mobile navigation menu
- FAQ accordion
- Dynamically rendered pet cards and events
- Pet search and dog/cat filter
- Form validation and demonstration response
- Accessible image lightbox
- Semantic page structure, titles, descriptions and internal navigation

## Important project notes
This is a fictional student project. Pet profiles, events, email, phone and location details are examples. Replace them with verified details if the site is for a real shelter.

The forms validate in the browser but do not send or store submissions. A real website needs a secure backend or trusted form service. Images are loaded from Unsplash URLs and therefore need an internet connection.

## Suggested Git commit plan
1. `Create initial shelter website structure`
2. `Add shared responsive stylesheet and navigation`
3. `Add home and about pages`
4. `Add shelter services and FAQ accordion`
5. `Add pet profiles with search and filter`
6. `Add dynamic events and enquiry forms`
7. `Add contact and privacy pages`
8. `Update documentation and test website`

## Testing checklist
- Open every page from the navigation.
- Resize the browser to test mobile layout.
- Test the menu on a narrow screen.
- Search for a pet by name and filter dogs/cats.
- Open and close the FAQ accordion.
- Submit forms with missing and valid details.
- Check image loading and browser console for errors.
- Confirm all links and page names are correct.
